package main

import (
	impl "sinaclouds/echo/internal/impl/service"
	pb "sinaclouds/echo/service"
	"sinaclouds/fx/common/log"
	"sinaclouds/fx/core"
)

func main() {
	host := core.NewRpcHosting()
	pb.RegisterEchoServer(host.Server, &impl.SimpleEchoServerImpl{})

	if err := host.Run(); err != nil {
		log.Fatal("Failed to host run: %v", err)
	}
}
