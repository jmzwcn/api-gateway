package service

import (
	pb "sinaclouds/echo/service"
	"sinaclouds/fx/core"
	"time"

	"github.com/gogo/protobuf/types"
	"golang.org/x/net/context"
)

type SimpleEchoServerImpl struct {
	core.InjectionService
}

func (s *SimpleEchoServerImpl) Echo(ctx context.Context, req *pb.EchoRequest) (*pb.EchoResponse, error) {
	return &pb.EchoResponse{
		Text: req.Text,
	}, nil
}
func (s *SimpleEchoServerImpl) Ping(ctx context.Context, req *types.Empty) (*types.Timestamp, error) {
	//s.DB(ctx)
	now := time.Now()
	return &types.Timestamp{
		Seconds: now.Unix(),
		Nanos:   int32(now.Nanosecond()),
	}, nil
}
