// GENERATE PROTO CODE, DON'T REMOVE
//go:generate sh -c "make -f $PWD/../../fx/core/Makefile generate-go"

package echo
