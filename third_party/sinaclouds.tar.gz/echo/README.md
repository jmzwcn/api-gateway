
## Usage:

1. install [golang](https://golang.org/), [protoc](https://github.com/google/protobuf/releases);
2. cd ../devenv; 
3. make

## How to define a service
1. cd ../template's service
2. for more detail, please refer to [here](https://cloud.google.com/service-management/reference/rpc/google.api#http)
