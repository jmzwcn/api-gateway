package version

import (
	"fmt"
	"time"
)

var (
	version, gitCommit string
	created            = time.Now()
)

// GetVersion
func GetVersion() string {
	return version
}

// GetGitCommit
func GetGitCommit() string {
	return gitCommit
}

func GetBuildAt() time.Time {
	return created
}

// GetCompleteVersion
func GetCompleteVersion() string {
	return fmt.Sprintf("%s-%s (%s)", GetVersion(), GetGitCommit(), GetBuildAt())
}
