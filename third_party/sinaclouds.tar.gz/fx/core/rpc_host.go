package core

import (
	"net"
	"sinaclouds/fx/core/config"
	"sinaclouds/fx/core/interceptor"

	"google.golang.org/grpc"
)

type RpcHosting struct {
	Server *grpc.Server
	listen net.Listener
}

func NewRpcHosting() *RpcHosting {
	server := grpc.NewServer(grpc.UnaryInterceptor(ChainUnaryServer(
		interceptor.Recovery(),
		interceptor.DependInject(),
		interceptor.Authenticate(),
	)))
	return &RpcHosting{Server: server}
}

func (s *RpcHosting) Run() error {
	lis, err := net.Listen("tcp", config.Addr)
	if err != nil {
		return err
	}
	s.listen = lis
	return s.Server.Serve(s.listen)
}
