package interceptor

import (
	cost "sinaclouds/cost/service"
	"sinaclouds/fx/common/constants"
	"sinaclouds/fx/common/rpc"
	"sinaclouds/fx/core/md"
	user "sinaclouds/user/service"
	"strings"

	wrappers "github.com/gogo/protobuf/types"
	"golang.org/x/net/context"
	"google.golang.org/grpc"
	"google.golang.org/grpc/codes"
)

func Authenticate() grpc.UnaryServerInterceptor {
	return func(ctx context.Context, req interface{}, info *grpc.UnaryServerInfo, handler grpc.UnaryHandler) (interface{}, error) {
		if md.HttpRequest(ctx) != nil { //check from gateway
			auth := md.Option("runtime.authentication", ctx)
			if auth == nil || auth.(bool) {
				conn := rpc.Dial("user")
				defer conn.Close()
				tc := user.NewTokensClient(conn)
				if userId, err := tc.Check(ctx, &wrappers.StringValue{Value: md.Header(ctx).Get("X-Signature")}); userId != nil {
					//role check
					requestMethod := info.FullMethod
					if strings.Contains(requestMethod, "/cost.Tickets/Update") {
						if ticket, ok := req.(*cost.Ticket); ok {
							if (ticket.Status > 1 && ticket.Status != 4) && !haveRoles(ctx, conn, userId, constants.CostControl, constants.ITAdminCommittee, constants.SystemAdmin) {
								return nil, grpc.Errorf(codes.PermissionDenied, "Permission Denied.")
							}
						}
					}

					if strings.Contains(requestMethod, "/cost.Specification") || strings.Contains(requestMethod, "/cost.Prices") {
						if strings.Contains(requestMethod, "Get") || strings.Contains(requestMethod, "List") {
							return handler(ctx, req)
						}
						if !haveRoles(ctx, conn, userId, constants.IDCBiz, constants.SystemAdmin) {
							return nil, grpc.Errorf(codes.PermissionDenied, "Permission Denied.")
						}
					}

					// switch info.FullMethod {
					// case "/cost.Tickets/Update":
					// 	if ticket, ok := req.(*cost.Ticket); ok {
					// 		if ticket.Status > 1 && !(haveRole(ctx, userId, constants.CostControl, conn) || haveRole(ctx, userId, constants.CostControl, conn)) {
					// 			return nil, grpc.Errorf(codes.PermissionDenied, "Permission Denied.")
					// 		}
					// 	}
					// case "/cost.Specification/Add", "/cost.Specification/Update", "/cost.Specification/Delete":
					// 	if !haveRole(ctx, userId, constants.IDCBiz, conn) {
					// 		return nil, grpc.Errorf(codes.PermissionDenied, "Permission Denied.")
					// 	}
					// default:
					// 	log.Debug("...")
					// }

				} else {
					return nil, err
				}
			}
		}

		return handler(ctx, req)
	}
}

func haveRoles(ctx context.Context, conn *grpc.ClientConn, userId *wrappers.StringValue, expectedRoles ...user.Role) bool {
	roles, _ := user.NewRolesClient(conn).GetByUserId(ctx, &user.RoleRequestByUserId{UserId: userId.Value})
	for _, role := range roles.Items {
		for _, expectedRole := range expectedRoles {
			if role.Id == expectedRole.Id {
				return true
			}
		}
	}
	return false
}
