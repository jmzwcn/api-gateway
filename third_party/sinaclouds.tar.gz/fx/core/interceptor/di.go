package interceptor

import (
	"sinaclouds/fx/common/constants"
	"sinaclouds/fx/common/db"
	"sinaclouds/fx/core/types"

	"golang.org/x/net/context"
	"google.golang.org/grpc"
)

func DependInject() grpc.UnaryServerInterceptor {
	return func(ctx context.Context, req interface{}, info *grpc.UnaryServerInfo, handler grpc.UnaryHandler) (interface{}, error) {
		//Inject current DB and NO create a new one.[why:http://go-database-sql.org/accessing.html]
		deps := types.Injector{DB: db.DB}
		cc := context.WithValue(ctx, constants.SHCMP_CTX, &deps)
		return handler(cc, req)
	}
}
