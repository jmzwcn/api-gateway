package md

import (
	"net/http"
	"testing"

	"google.golang.org/grpc/metadata"
)

func TestTransferHeader2MD(t *testing.T) {
	hdr := http.Header{}
	hdr.Set("key", "value")

	mdt := metadata.MD(hdr)
	t.Logf("%T -> %T", hdr, mdt)
}
