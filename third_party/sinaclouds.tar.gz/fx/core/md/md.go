package md

import (
	"encoding/json"
	"net/http"
	"sinaclouds/fx/common/constants"
	"sinaclouds/fx/common/log"
	"sinaclouds/fx/core/types"

	"golang.org/x/net/context"
	"google.golang.org/grpc/metadata"
)

func Option(key string, ctx context.Context) interface{} {
	if md, ok := metadata.FromIncomingContext(ctx); ok {
		if opts, ok := md[constants.RPC_METHOD_OPTIONS]; ok && len(opts) > 0 {
			var options map[string]interface{}
			err := json.Unmarshal([]byte(opts[0]), &options)
			if err != nil {
				log.Errorf("Option(): %s", err)
				return nil
			}
			return options[key]
		}
	}
	return nil
}

func HttpRequest(ctx context.Context) *types.HttpRequest {
	if md, ok := metadata.FromIncomingContext(ctx); ok {
		if requestStr, ok := md[constants.HTTP_REQUEST]; ok && len(requestStr) > 0 {
			var request types.HttpRequest
			err := json.Unmarshal([]byte(requestStr[0]), &request)
			if err != nil {
				log.Errorf("HttpRequest(): %s", err)
				return nil
			}
			return &request
		}
	}
	return nil
}

func Header(ctx context.Context) http.Header {
	return HttpRequest(ctx).Header
}

func URLValues(key string, ctx context.Context) string {
	return HttpRequest(ctx).Form.Get(key)
}
