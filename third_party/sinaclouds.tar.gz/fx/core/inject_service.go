package core

import (
	"database/sql"
	"sinaclouds/fx/bus/cache"
	"sinaclouds/fx/common/constants"
	"sinaclouds/fx/common/log"
	"sinaclouds/fx/common/rpc"
	"sinaclouds/fx/core/md"
	"sinaclouds/fx/core/types"
	pb "sinaclouds/user/service"
	"strings"

	"golang.org/x/net/context"
)

type InjectionService struct {
}

func mustGet(ctx context.Context) *types.Injector {
	if value := ctx.Value(constants.SHCMP_CTX); value != nil {
		if value, ok := value.(*types.Injector); ok {
			return value
		}
	}
	panic("Key \"" + constants.SHCMP_CTX + "\" does not exist")
}

func (i *InjectionService) Cache() cache.ICache {
	return cache.DefaultCache()
}

func (i *InjectionService) DB(ctx context.Context) *sql.DB {
	return mustGet(ctx).DB
}

func (i *InjectionService) Token(ctx context.Context) string {
	return strings.Split(i.Header("X-Signature", ctx), ":")[0]
}

func (i *InjectionService) User(ctx context.Context) *pb.User {
	user := new(pb.User)
	if err := i.Cache().GetTo(i.Token(ctx), user); err != nil {
		log.Error(err)
	} else {
		return user
	}
	//from DB when error
	conn := rpc.Dial("user")
	defer conn.Close()
	if user, err := pb.NewUsersClient(conn).GetByToken(ctx, &pb.TokenRequest{Token: i.Token(ctx)}); err != nil {
		log.Error(err)
	} else {
		return user
	}
	return nil
}

func (i *InjectionService) Option(key string, ctx context.Context) interface{} {
	return md.Option(key, ctx)
}

func (i *InjectionService) HttpRequest(ctx context.Context) *types.HttpRequest {
	return md.HttpRequest(ctx)
}

func (i *InjectionService) Header(key string, ctx context.Context) string {
	return md.Header(ctx).Get(key)
}

func (i *InjectionService) HaveRoles(ctx context.Context, userId string, expectedRoles ...pb.Role) bool {
	conn := rpc.Dial("user")
	defer conn.Close()
	roles, _ := pb.NewRolesClient(conn).GetByUserId(ctx, &pb.RoleRequestByUserId{UserId: userId})
	for _, role := range roles.Items {
		for _, expectedRole := range expectedRoles {
			if role.Id == expectedRole.Id {
				return true
			}
		}
	}
	return false
}
