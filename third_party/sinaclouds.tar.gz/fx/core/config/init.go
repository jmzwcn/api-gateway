package config

import (
	"flag"
	"fmt"
	"os"
	"sinaclouds/fx/common/log"
	"sinaclouds/fx/core/version"
	"strings"
)

var (
	Addr              string
	DBURL             string
	REDISURL          string
	LogLevel          string
	Domain            string
	CASURL            string
	Suffix            string
	isHelp, isVersion bool
	cmd               *flag.FlagSet
)

func init() {
	cmd = flag.NewFlagSet("shcmp", flag.ContinueOnError)
	cmd.StringVar(&Addr, "addr", ":50051", "Host Bind address")
	cmd.StringVar(&DBURL, "dbURL", "root:Shcmp@sina.com@tcp(10.13.1.186:3306)/shcmp", "DB URL")
	cmd.StringVar(&REDISURL, "redisURL", "10.13.1.186:6379", "Redis URL PassWord/RedisHost:Port/DBIndex")
	cmd.StringVar(&Domain, "domain", "http://shcmp.intra.sina.com.cn", "Domain")
	cmd.StringVar(&CASURL, "CASURL", "https://cas.erp.sina.com.cn/", "Sina CAS")
	cmd.StringVar(&LogLevel, "logLevel", "debug", "Log Level")
	cmd.StringVar(&Suffix, "suffix", "", "Service Suffix")
	cmd.BoolVar(&isHelp, "help", false, "Print this help")
	cmd.BoolVar(&isVersion, "version", false, "Print this version")
	cmd.Parse(args(cmd))

	log.SetLevel(LogLevel)
	if isHelp {
		showHelp()
	}
	if isVersion {
		showVersion()
	}
}

func showHelp() {
	cmd.PrintDefaults()
	os.Exit(1)
}

func showVersion() {
	fmt.Println(version.GetCompleteVersion())
	os.Exit(1)
}

func args(fs *flag.FlagSet) (args []string) {
	left := strings.Join(os.Args, " ")
	for _, v := range os.Args {
		key := strings.TrimLeft(strings.Split(v, "=")[0], "-")
		if fs.Lookup(key) != nil {
			args = append(args, v)
			left = strings.Replace(left, " "+v, "", -1)
		}
	}
	os.Args = strings.Split(left, " ")
	return args
}
