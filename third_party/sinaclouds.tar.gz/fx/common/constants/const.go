package constants

import (
	pb "sinaclouds/user/service"
)

//ConfigMap used
const (
	MountPath       = "MountPath"
	Content         = "Content"
	FileMode        = "FileMode"
	PostAction      = "PostAction"
	UpdateTimestamp = "UpdateTimestamp"
)

var (
	SystemAdmin      = pb.Role{Id: "R1", Name: "超级管理员", Description: "全局权限、readonly", UserIds: []string{"1FAD56F8-3F6C-40FA-A504-9E014A6EA00A"}}
	ITAdminCommittee = pb.Role{Id: "R2", Name: "IT管委会", Description: "IT管委会"}
	CostControl      = pb.Role{Id: "R3", Name: "成本控制", Description: "资源审批、费用查看、账单查看"}
	Opts             = pb.Role{Id: "R4", Name: "运维人员", Description: "资源申请、实例管理"}
	IDCBiz           = pb.Role{Id: "R5", Name: "IDC商务", Description: "规格管理、单价管理"}
	NetworkAdmin     = pb.Role{Id: "R6", Name: "网络管理员", Description: "修改交换机配置"}
)
