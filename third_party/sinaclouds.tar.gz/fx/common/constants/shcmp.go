package constants

//NO include any biz related.
const (
	SHCMP_CTX          = "shcmp_context"
	RPC_SERVER_PORT    = "50051"
	HTTP_REQUEST       = "http_request"
	RPC_METHOD_OPTIONS = "rpc_method_options"
)
