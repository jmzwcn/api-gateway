package grpcstatus

import (
	"google.golang.org/grpc/codes"
)

const (
	// for http 302
	StatusMoved codes.Code = iota + 10031
	StatusNoRoute
)
