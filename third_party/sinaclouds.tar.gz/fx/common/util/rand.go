package util

import (
	"math/rand"
	"strconv"
	"time"
)

const ALPHANUM = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"

func RandString(count int) string {
	if count <= 0 {
		return ""
	}

	r := rand.New(rand.NewSource(time.Now().UnixNano()))
	sets := []byte(ALPHANUM)
	var ret = make([]byte, count)
	setlen := len(ALPHANUM)
	for i := 0; i < count; i++ {
		ret[i] = sets[r.Intn(setlen-1)]
	}
	return string(ret)
}

func UUID() string {
	return strconv.Itoa(time.Now().Second()) + strconv.Itoa(time.Now().Nanosecond()) + RandString(1)
}
