package util

import (
	"fmt"
	"testing"
)

func TestMulti(t *testing.T) {
	fmt.Println(UUID())
}
