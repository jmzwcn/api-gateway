package util

//remove duplicated
func Append(old []string, values ...string) []string {
	old = append(old, values...)
	keysMap := map[string]string{}
	for _, v := range old {
		keysMap[v] = v
	}
	newValues := []string{}
	for k := range keysMap {
		newValues = append(newValues, k)
	}
	return newValues
}

func Delete(old []string, values ...string) []string {
	keysMap := map[string]string{}
	for _, v := range old {
		keysMap[v] = v
	}
	for _, v := range values {
		delete(keysMap, v)
	}
	newValues := []string{}
	for k := range keysMap {
		newValues = append(newValues, k)
	}
	return newValues
}

func Across(array1 []string, array2 []string) []string {
	newArray := []string{}
	for _, v := range array1 {
		for _, j := range array2 {
			if j == v {
				newArray = append(newArray, j)
			}
		}
	}
	return newArray
}
