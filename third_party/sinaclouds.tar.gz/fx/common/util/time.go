package util

import (
	"time"

	timestamp "github.com/gogo/protobuf/types"
)

func TimestampToTime(t *timestamp.Timestamp) time.Time {
	if &t == nil {
		return time.Time{}
	}

	return time.Unix(t.Seconds, int64(t.Nanos))
}

func TimeToTimestamp(t time.Time) *timestamp.Timestamp {
	if &t == nil {
		return nil
	}

	return &timestamp.Timestamp{
		Seconds: t.Unix(),
		Nanos:   int32(t.Nanosecond()),
	}
}

func ToTimestamp(seconds int64, nanos int32) *timestamp.Timestamp {
	return &timestamp.Timestamp{
		Seconds: seconds,
		Nanos:   nanos,
	}
}

func Now() *timestamp.Timestamp {
	return TimeToTimestamp(time.Now())
}

func NowP() *time.Time {
	t := time.Now()
	return &t
}
