package rpc

import (
	"fmt"
	pb "sinaclouds/echo/service"
	"testing"
	"time"

	"golang.org/x/net/context"
	"google.golang.org/grpc"
)

func TestMulti(t *testing.T) {
	rpcConn, err := grpc.Dial("10.13.32.252:50052", grpc.WithInsecure())
	if err != nil {
		fmt.Println(err)
	}

	fmt.Println(time.Now())
	go func() {
		resp1, _ := pb.NewEchoClient(rpcConn).Echo(context.Background(),
			&pb.EchoRequest{Text: "111", Delay: 10})
		fmt.Println(resp1.Text, time.Now())
	}()

	time.Sleep(2 * time.Second)
	go func() {
		resp2, _ := pb.NewEchoClient(rpcConn).Echo(context.Background(),
			&pb.EchoRequest{Text: "222", Delay: 1})
		fmt.Println(resp2.Text, time.Now())
	}()

	time.Sleep(10 * time.Second)
}
