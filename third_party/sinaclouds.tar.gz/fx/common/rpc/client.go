package rpc

import (
	"sinaclouds/fx/common/constants"
	"sinaclouds/fx/common/log"
	"sinaclouds/fx/core/config"

	"google.golang.org/grpc"
)

func Dial(service string) *grpc.ClientConn {
	endpoint := service + config.Suffix
	rpcConn, err := grpc.Dial(endpoint+":"+constants.RPC_SERVER_PORT, grpc.WithInsecure())
	if err != nil {
		log.Error(err)
		panic(err)
	}
	return rpcConn
}
