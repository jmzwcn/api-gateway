package cache

import "time"

type (
	// The cache interface
	ICache interface {
		// Check key exists
		Exists(key string) (bool, error)

		// Get value
		Get(key string) (string, error)

		//json.Unmarshal to target
		GetTo(key string, target interface{}) error

		// Set a value
		Set(key string, value interface{}) error

		// Set a value with TTL
		SetWithTTL(key string, value interface{}, ttl time.Duration) error

		// Delet by key
		Delete(key string) (int, error)

		// Send a custom command
		Send(commandName string, args ...interface{}) (interface{}, error)
	}
)
