package cache

import (
	"sinaclouds/fx/core/config"
)

var Cache = NewRedisCache(config.REDISURL) //NewInMemoryCache()

func DefaultCache() ICache {
	return Cache
}
