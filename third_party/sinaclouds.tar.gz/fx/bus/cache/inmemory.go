package cache

import (
	"errors"
	"time"
)

type InMemoryCache struct {
	ICache
	values    map[string]interface{}
	ttlTimers map[string]*time.Timer
}

func NewInMemoryCache() *InMemoryCache {
	return &InMemoryCache{
		values:    make(map[string]interface{}),
		ttlTimers: make(map[string]*time.Timer),
	}
}

func ensureKey(key string) error {
	if key == "" {
		return errors.New("Key can not be empty.")
	}
	return nil
}

func (c *InMemoryCache) Exists(key string) (bool, error) {
	if err := ensureKey(key); err != nil {
		return false, err
	}
	_, ok := c.values[key]
	return ok, nil
}

func (c *InMemoryCache) Get(key string) (interface{}, error) {
	if err := ensureKey(key); err != nil {
		return "", err
	}
	if v, ok := c.values[key]; ok {
		return v, nil
	}
	return "", errors.New("Can not found key " + key)
}

func (c *InMemoryCache) Set(key string, value interface{}) error {
	if err := ensureKey(key); err != nil {
		return err
	}

	// switch v := value.(type) {
	// case bool:
	// 	c.values[key] = strconv.FormatBool(v)
	// case int:
	// 	c.values[key] = strconv.FormatInt(int64(v), 10)
	// case int8:
	// 	c.values[key] = strconv.FormatInt(int64(v), 10)
	// case int16:
	// 	c.values[key] = strconv.FormatInt(int64(v), 10)
	// case int32:
	// 	c.values[key] = strconv.FormatInt(int64(v), 10)
	// case int64:
	// 	c.values[key] = strconv.FormatInt(int64(v), 10)
	// case uint:
	// 	c.values[key] = strconv.FormatUint(uint64(v), 10)
	// case uint8:
	// 	c.values[key] = strconv.FormatUint(uint64(v), 10)
	// case uint16:
	// 	c.values[key] = strconv.FormatUint(uint64(v), 10)
	// case uint32:
	// 	c.values[key] = strconv.FormatUint(uint64(v), 10)
	// case uint64:
	// 	c.values[key] = strconv.FormatUint(uint64(v), 10)
	// case string:
	// 	c.values[key] = v
	// default:
	// 	return errors.New("Not supported type.")
	// }
	c.values[key] = value
	return nil
}

func (c *InMemoryCache) SetWithTTL(key string, value interface{}, ttl time.Duration) error {
	if ttl.Nanoseconds() == 0 {
		return nil
	}

	if oldTimer, ok := c.ttlTimers[key]; ok {
		oldTimer.Stop()
	}

	c.Set(key, value)
	timer := time.AfterFunc(ttl, func() {
		c.Delete(key)
		delete(c.ttlTimers, key)
	})
	c.ttlTimers[key] = timer

	return nil
}

func (c *InMemoryCache) Delete(key string) (int, error) {
	rawLen := len(c.values)
	delete(c.values, key)
	return rawLen - len(c.values), nil
}

func (c *InMemoryCache) Send(commandName string, args ...interface{}) (interface{}, error) {
	panic("NOT SUPPORTED OPERATION.")
}
