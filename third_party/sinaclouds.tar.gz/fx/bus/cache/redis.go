package cache

import (
	"encoding/json"
	"time"

	"gopkg.in/redis.v4"
)

type RedisCache struct {
	ICache
	client *redis.Client
}

func NewRedisCache(address string) *RedisCache {
	return &RedisCache{
		client: redis.NewClient(&redis.Options{
			Addr:     address,
			Password: "", // no password set
			DB:       0,  // use default DB
		}),
	}
}

func (c *RedisCache) Exists(key string) (bool, error) {
	cmd := c.client.Exists(key)
	return cmd.Val(), cmd.Err()
}

func (c *RedisCache) Get(key string) (string, error) {
	val, err := c.client.Get(key).Result()
	if err == redis.Nil {
		err = nil
	}
	return val, err
}

func (c *RedisCache) GetTo(key string, target interface{}) error {
	value, err := c.Get(key)
	if err != nil {
		return err
	}

	if err := json.Unmarshal([]byte(value), target); err != nil {
		return err
	}
	return nil
}

func (c *RedisCache) Set(key string, value interface{}) error {
	vv, err := json.Marshal(value)
	if err != nil {
		return err
	}
	return c.client.Set(key, string(vv), time.Duration(0)).Err()
}

func (c *RedisCache) SetWithTTL(key string, value interface{}, ttl time.Duration) error {
	return c.client.Set(key, value, ttl).Err()
}

func (c *RedisCache) Delete(key string) (int, error) {
	cmd := c.client.Del(key)
	return int(cmd.Val()), cmd.Err()
}

func (c *RedisCache) Send(commandName string, args ...interface{}) (interface{}, error) {
	commandArgs := []interface{}{commandName}
	commandArgs = append(commandArgs, args...)
	cmd := redis.NewCmd(commandArgs...)
	c.client.Process(cmd)
	return cmd.Val(), cmd.Err()
}
