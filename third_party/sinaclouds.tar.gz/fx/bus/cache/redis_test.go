// +build integration

package cache

import (
	"testing"
	"time"
)

// Test interface implement
var _ ICache = NewRedisCache(ExternalHost("redis") + ":6379")

func createClient() *RedisCache {
	c := NewRedisCache(ExternalHost("redis") + ":6379")
	// Cleanup all keys
	_, err := c.Send("FLUSHALL")
	if err != nil {
		panic(err)
	}

	return c
}

func TestRedis_Exists(t *testing.T) {
	cache := createClient()

	cache.Set("Trick", "NO ONE IS THERE")

	v, err := cache.Exists("Trick")
	if err != nil {
		t.Error(err)
		return
	}
	if !v {
		t.Errorf("Key not exists.")
	}
}

func TestRedis_Get(t *testing.T) {
	cache := createClient()

	cache.Set("Trick", "NO ONE IS THERE")

	v, _ := cache.Get("Trick")
	if v != "NO ONE IS THERE" {
		t.Errorf("Can not get value or not match.")
	}
}

func TestRedis_Set(t *testing.T) {
	cache := createClient()

	cache.Set("Trick", "NO ONE IS THERE")
	cache.Set("PORT", 3389)

	trick, _ := cache.Get("Trick")
	if trick != "NO ONE IS THERE" {
		t.Errorf("Trick not match.")
	}
	port, _ := cache.Get("PORT")
	if port != "3389" {
		t.Errorf("Port not match.")
	}
}

func TestRedis_SetWithTTL(t *testing.T) {
	cache := createClient()

	cache.SetWithTTL("Name", "Moorse", time.Duration(100*time.Millisecond))

	name, _ := cache.Get("Name")
	if name != "Moorse" {
		t.Errorf("Name not match.")
	}

	go func() {
		time.Sleep(50 * time.Millisecond)
		exist, _ := cache.Exists("Name")
		if exist {
			t.Errorf("Name must not exists.")
		}
	}()
}

func TestRedis_Delete(t *testing.T) {
	cache := createClient()

	cache.Set("Name", "Bleed")

	count, err := cache.Delete("Name")
	if count <= 0 || err != nil {
		t.Errorf("Not delete key.")
	}
}

func TestRedis_Send(t *testing.T) {
	cache := createClient()

	ret, err := cache.Send("PING")
	if ret.(string) != "PONG" || err != nil {
		t.Error("Result not replay PONG.")
	}
}
