package cache

import (
	"testing"
	"time"
)

// Test interface implement
var _ ICache = NewInMemoryCache()

func TestMem_Exists(t *testing.T) {
	cache := NewInMemoryCache()

	cache.values["Name"] = "Jessie"

	v, err := cache.Exists("Name")
	if !v || err != nil {
		t.Errorf("Key not exists.")
	}
}

func TestMem_Get(t *testing.T) {
	cache := NewInMemoryCache()

	cache.values["Name"] = "Jessie"

	v, _ := cache.Get("Name")
	if v != "Jessie" {
		t.Errorf("Can not get value or not match.")
	}
}

func TestMem_Set(t *testing.T) {
	cache := NewInMemoryCache()

	cache.Set("Name", "Moorse")
	cache.Set("Age", 37)
	cache.Set("IsMale", true)

	name, _ := cache.Get("Name")
	if name != "Moorse" {
		t.Errorf("Name not match.")
	}
	age, _ := cache.Get("Age")
	if age != "37" {
		t.Errorf("Age not match.")
	}
	isMale, _ := cache.Get("IsMale")
	if isMale != "true" {
		t.Errorf("IsMale not match.")
	}
}

func TestMem_SetWithTTL(t *testing.T) {
	cache := NewInMemoryCache()

	cache.SetWithTTL("Name", "Moorse", time.Duration(100*time.Millisecond))

	name, _ := cache.Get("Name")
	if name != "Moorse" {
		t.Errorf("Name not match.")
	}

	wait := make(chan struct{}, 1)
	go func() {
		time.Sleep(300 * time.Millisecond)
		exist, _ := cache.Exists("Name")
		if exist {
			t.Errorf("Name must not exists.")
		}

		wait <- struct{}{}
	}()

	<-wait
}

func TestMem_Delete(t *testing.T) {
	cache := NewInMemoryCache()

	cache.Set("Name", "Moorse")

	count, err := cache.Delete("Name")
	if count <= 0 || err != nil {
		t.Errorf("Not delete key.")
	}
}

func TestMem_Send(t *testing.T) {
	cache := NewInMemoryCache()

	defer func() {
		if r := recover(); r != nil {
			if r.(string) != "NOT SUPPORTED OPERATION." {
				t.Error("Not matched error :", r)
			}
			return
		}
		t.Error("No any panic.")
	}()
	cache.Send("XXX", 1, 2, 3, 4)
}
