package mail

import (
	"testing"
)

func TestSend(t *testing.T) {
	msg := NewHTMLMessage("Email subject", "<h1>email body...中文...</h1>")
	msg.To = []string{"zhangwei35@staff.sina.com.cn"}
	Send(msg)
}
