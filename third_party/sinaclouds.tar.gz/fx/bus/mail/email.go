package mail

import (
	"net/mail"
	"net/smtp"
)

func Send(msg *Message) error {
	//mail.From must be shcmp
	msg.From = mail.Address{
		Name:    "shcmp",
		Address: "shcmp@staff.sina.com.cn"}
	return smtp.SendMail("mail.staff.sina.com.cn:587", auth(), msg.From.Address, msg.ToList(), msg.Bytes())
}
